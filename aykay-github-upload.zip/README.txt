AYKAY COMING SOON SITE

WHAT'S INCLUDED
- Mobile-first coming-soon landing page
- Blue thread-effect AYKAY wordmark (CSS placeholder until the final embroidered logo asset is ready)
- Email signup endpoint backed by Cloudflare D1
- Server-side password check endpoint for early access
- Basic privacy notice template

IMPORTANT BEFORE LAUNCH
1. Replace [ADD YOUR BRAND CONTACT EMAIL] in privacy.html with a real monitored email address.
2. The email list is stored in Cloudflare D1. No marketing email is sent automatically; connect an email platform and obtain any required setup/consent before sending campaigns.
3. The password endpoint validates the shared password server-side, but the early-access page/content has not yet been built. Do not put private product pages behind a client-side-only hide/show control.
4. Set a strong unique ACCESS_PASSWORD secret in Cloudflare. Do not put it in index.html or app.js.

DEPLOY WITH CLOUDFLARE PAGES (FREE TIER SUBJECT TO CLOUDFLARE'S CURRENT LIMITS)
1. Create a Cloudflare account and a GitHub account if you do not already have them.
2. Create a new GitHub repository and upload the contents of this folder to the repository root.
3. In Cloudflare Dashboard, go to Workers & Pages -> Create -> Pages -> Connect to Git.
4. Select the repository. Framework preset: None. Build command: leave blank. Build output directory: / (or set the output directory to the repository root if prompted).
5. Create a D1 database named aykay-signups in Cloudflare Dashboard.
6. In the D1 console, run the contents of schema.sql.
7. In Pages -> your project -> Settings -> Functions, add a D1 database binding:
   Variable name: DB
   D1 database: aykay-signups
8. Add an environment variable/secret named ACCESS_PASSWORD with your chosen strong shared password. Use a secret, not a plain public variable if the dashboard offers that choice.
9. Redeploy the Pages project after adding bindings/secrets.
10. Test a signup using an email address you control and confirm a row appears in the D1 signups table. Test a wrong and correct access password.

CUSTOM DOMAIN
You can initially use the free *.pages.dev address. A custom domain normally costs money from a domain registrar; connect it in Cloudflare Pages when you are ready.

EMAIL EXPORT
You can view the signups table in Cloudflare D1 and export/query it from the dashboard. The site currently stores addresses; it does not send emails or provide an unsubscribe-management system. Add a mailing-list provider before sending marketing emails and make sure unsubscribe requests are handled.
